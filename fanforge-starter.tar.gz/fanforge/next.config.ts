import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "api.gmi-serving.com",
      },
    ],
  },
};

export default nextConfig;
