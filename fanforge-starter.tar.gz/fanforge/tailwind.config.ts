import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/**/*.{ts,tsx,js,jsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        /* Primary palette — Yellow Sunset */
        cream:          "#f6e7a1",
        gold:           "#f1c40f",
        orange:         "#e67e22",
        "deep-orange":  "#d35400",

        /* Warm neutrals */
        "bg-primary":   "#fefcf4",
        "bg-secondary": "#faf5e4",
        "bg-tertiary":  "#f5ecd0",
        "surface-dark": "#2c1810",

        "text-primary":   "#1a0f07",
        "text-secondary": "#5c4a3a",
        "text-tertiary":  "#8b7355",
      },
      fontFamily: {
        display: ['"Playfair Display"', "Georgia", "serif"],
        body:    ['"DM Sans"', "system-ui", "sans-serif"],
      },
      borderRadius: {
        sm:   "6px",
        md:   "10px",
        lg:   "14px",
        xl:   "20px",
        pill: "999px",
      },
      boxShadow: {
        "warm-sm":  "0 1px 3px rgba(44, 24, 16, 0.06)",
        "warm-md":  "0 4px 12px rgba(44, 24, 16, 0.08)",
        "warm-lg":  "0 8px 24px rgba(44, 24, 16, 0.12)",
        "warm-xl":  "0 16px 48px rgba(44, 24, 16, 0.16)",
        "gold-glow": "0 0 24px rgba(241, 196, 15, 0.3)",
      },
      spacing: {
        "sidebar-collapsed": "64px",
        "sidebar-expanded":  "240px",
      },
      animation: {
        "pulse-gold": "pulseGold 2s ease-in-out infinite",
        "fade-in":    "fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1)",
        "slide-up":   "slideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1)",
        "scale-in":   "scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)",
      },
      keyframes: {
        pulseGold: {
          "0%, 100%": { boxShadow: "0 0 16px rgba(241, 196, 15, 0.2)" },
          "50%":      { boxShadow: "0 0 32px rgba(241, 196, 15, 0.5)" },
        },
        fadeIn: {
          from: { opacity: "0" },
          to:   { opacity: "1" },
        },
        slideUp: {
          from: { opacity: "0", transform: "translateY(16px)" },
          to:   { opacity: "1", transform: "translateY(0)" },
        },
        scaleIn: {
          from: { opacity: "0", transform: "scale(0.95)" },
          to:   { opacity: "1", transform: "scale(1)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
