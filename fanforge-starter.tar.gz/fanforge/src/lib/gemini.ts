import { GoogleGenerativeAI } from "@google/generative-ai";

/**
 * Google AI Studio client — Gemini models with optional Search grounding.
 * Used for Node 2 (Knowledge Enrichment) to fetch live World Cup data.
 *
 * Usage:
 *   const data = await askGemini("What is Brazil's World Cup 2026 group?");
 */

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_STUDIO_KEY!);

const model = genAI.getGenerativeModel({
  model: "gemini-2.5-flash",
  /* Enable search grounding for live data (schedule, stats, etc.) */
  tools: [{ googleSearch: {} } as any],
});

/* ─── Helper: ask Gemini with search grounding ──────────────── */

export async function askGemini(prompt: string): Promise<string> {
  const result = await model.generateContent(prompt);
  return result.response.text();
}

/* ─── Helper: get structured team profile ───────────────────── */

export async function getTeamProfile(teamName: string, playerMentions: string[]) {
  const prompt = `
You are a World Cup 2026 data assistant. Return ONLY valid JSON, no markdown.

For the team "${teamName}", provide:
{
  "team": "${teamName}",
  "group": "letter",
  "group_opponents": ["team1", "team2", "team3"],
  "next_match": {
    "opponent": "...",
    "date": "...",
    "time": "... ET",
    "venue": "...",
    "city": "..."
  },
  "colors": { "primary": "#hex", "secondary": "#hex", "accent": "#hex" },
  "nickname": "...",
  "cultural_keywords": ["word1", "word2", "word3"],
  "key_players": [
    { "name": "...", "position": "...", "club": "..." }
  ],
  "fifa_ranking": number,
  "fun_fact": "one-sentence interesting fact"
}

${playerMentions.length > 0 ? `The fan specifically mentioned: ${playerMentions.join(", ")}. Include these players in key_players.` : ""}

Search for the latest 2026 World Cup schedule and group assignments. The tournament runs June 11 - July 19, 2026 across USA, Canada, and Mexico.
`;

  const text = await askGemini(prompt);

  /* Strip any markdown fences if Gemini wraps them */
  const cleaned = text.replace(/```json\n?|```\n?/g, "").trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    console.error("Failed to parse Gemini response:", cleaned);
    return null;
  }
}
