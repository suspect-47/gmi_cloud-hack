import OpenAI from "openai";

/**
 * GMI Cloud client — OpenAI SDK pointed at GMI Cloud's inference endpoint.
 * All GMI models (LLM, image, TTS) use the same base URL.
 *
 * Usage:
 *   const response = await gmi.chat.completions.create({
 *     model: "deepseek-ai/DeepSeek-V3.2",
 *     messages: [{ role: "user", content: "Hello" }],
 *   });
 */
export const gmi = new OpenAI({
  apiKey: process.env.GMI_CLOUD_API_KEY!,
  baseURL: process.env.GMI_BASE_URL || "https://api.gmi-serving.com/v1",
});

/* ─── Model IDs ─────────────────────────────────────────────── */

export const MODELS = {
  /** Voice understanding — processes audio + extracts intent */
  VOICE_UNDERSTAND: "nvidia/NVIDIA-Nemotron-3-Nano-Omni",

  /** Creative director — generates prompts, copy, scripts */
  CREATIVE_DIRECTOR: "deepseek-ai/DeepSeek-V3.2",

  /** Fallback creative model */
  CREATIVE_FALLBACK: "Qwen/Qwen3-235B-A22B-FP8",

  /** Image generation */
  IMAGE_GEN: "black-forest-labs/FLUX",

  /** Voice synthesis */
  VOICE_SYNTH: "minimax-tts-speech-2.6-hd",
} as const;

/* ─── Helper: chat completion ───────────────────────────────── */

export async function gmiChat(
  model: string,
  messages: OpenAI.Chat.ChatCompletionMessageParam[],
  options?: { temperature?: number; maxTokens?: number }
) {
  const response = await gmi.chat.completions.create({
    model,
    messages,
    temperature: options?.temperature ?? 0.7,
    max_tokens: options?.maxTokens ?? 2000,
  });

  return response.choices[0]?.message?.content ?? "";
}
