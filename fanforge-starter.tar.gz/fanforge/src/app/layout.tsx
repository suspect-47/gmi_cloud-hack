import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FanForge — AI World Cup Content Engine",
  description:
    "Speak your team. Get a complete FIFA World Cup 2026 fan content kit in seconds.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-bg-primary text-text-primary min-h-screen">
        <div className="flex min-h-screen">
          {/* Sidebar — build in components/layout/Sidebar.tsx */}
          <aside className="w-sidebar-collapsed shrink-0 border-r border-r-[var(--color-border-light)] bg-bg-tertiary flex flex-col items-center py-6 gap-2">
            {/* Logo */}
            <div className="w-10 h-10 rounded-lg bg-gold flex items-center justify-center text-text-on-gold font-display font-bold text-lg mb-6">
              F
            </div>

            {/* Nav icons — replace with Sidebar component */}
            <div className="flex flex-col gap-1 flex-1">
              {/* Placeholder nav items */}
            </div>
          </aside>

          {/* Main content area */}
          <main className="flex-1 overflow-y-auto">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
