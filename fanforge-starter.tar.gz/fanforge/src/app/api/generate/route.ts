import { NextRequest, NextResponse } from "next/server";
import { v4 as uuid } from "uuid";
import { gmiChat, MODELS } from "@/lib/gmi";
import { getTeamProfile } from "@/lib/gemini";

/**
 * POST /api/generate
 *
 * Accepts either:
 *   - { audio: base64 string } — voice input (sent to Nemotron Omni)
 *   - { team: string, message?: string } — text fallback
 *
 * Returns:
 *   - { kit_id: string, status: "processing" }
 *
 * In production this triggers the full RocketRide pipeline.
 * For hackathon MVP, it runs nodes sequentially in this route.
 */

/* In-memory kit store (replace with RocketRide pipeline in production) */
const kitStore = new Map<string, any>();

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const kitId = uuid();

    /* ── Node 1: Extract team + intent ──────────────────────── */
    let teamName: string;
    let playerMentions: string[] = [];
    let fanEmotion: "casual" | "passionate" | "die-hard" = "passionate";

    if (body.audio) {
      /*
       * TODO: Send audio to Nemotron Omni via GMI Cloud for transcription
       * + intent extraction. For now, fall through to text input.
       *
       * const transcript = await gmiChat(MODELS.VOICE_UNDERSTAND, [...]);
       */
      teamName = body.team || "Brazil";
    } else {
      teamName = body.team;
      if (body.message) {
        /* Quick extraction of player names from message */
        playerMentions = []; // TODO: parse from message
        fanEmotion = body.message.includes("!") ? "die-hard" : "passionate";
      }
    }

    /* ── Node 2: Knowledge enrichment (Gemini + Search) ─────── */
    const teamProfile = await getTeamProfile(teamName, playerMentions);

    /* ── Node 3: Creative director (DeepSeek on GMI) ────────── */
    const creativePrompt = `
You are a world-class sports creative director. Given this team profile and fan context, generate a content kit.

Team profile:
${JSON.stringify(teamProfile, null, 2)}

Fan emotion level: ${fanEmotion}
Players mentioned: ${playerMentions.join(", ") || "none specifically"}

Return ONLY valid JSON with this exact structure:
{
  "image_prompts": {
    "matchday_poster": "detailed FLUX prompt for a cinematic matchday poster...",
    "fan_hype_card": "detailed FLUX prompt for a personalized fan card...",
    "social_cover": "detailed FLUX prompt for a social media cover image..."
  },
  "social_copy": {
    "instagram_caption": "...",
    "hashtags": ["#tag1", "#tag2", ...],
    "twitter_post": "...",
    "hot_take": "..."
  },
  "voice_script": "30-second narration script...",
  "watch_party": {
    "dishes": [
      { "name": "...", "description": "..." }
    ],
    "drink": "..."
  }
}

Rules:
- Image prompts must specify: lighting, camera angle, exact hex colors from the team profile, atmosphere, and composition.
- NEVER reference real player likenesses — use jersey numbers, silhouettes, or celebration poses.
- Social copy should feel like a real fan, not a brand.
- Voice script should build tension then release — give chills.
- Include 3 dishes from the team's national cuisine.
`;

    const creativeRaw = await gmiChat(MODELS.CREATIVE_DIRECTOR, [
      { role: "system", content: "You are a sports creative director. Respond only in valid JSON." },
      { role: "user", content: creativePrompt },
    ], { temperature: 0.8, maxTokens: 3000 });

    let creativeKit;
    try {
      const cleaned = creativeRaw.replace(/```json\n?|```\n?/g, "").trim();
      creativeKit = JSON.parse(cleaned);
    } catch {
      console.error("Failed to parse creative director output:", creativeRaw);
      creativeKit = null;
    }

    /* ── Node 4A: Image generation (FLUX on GMI) ────────────── */
    /*
     * TODO: Call FLUX via GMI Cloud image generation endpoint.
     * For hackathon MVP, store the prompts and generate on demand.
     *
     * const posterImage = await gmi.images.generate({
     *   model: MODELS.IMAGE_GEN,
     *   prompt: creativeKit.image_prompts.matchday_poster,
     *   size: "1024x1024",
     * });
     */

    /* ── Node 4B: Voice synthesis (Minimax TTS on GMI) ──────── */
    /*
     * TODO: Call Minimax TTS via GMI Cloud.
     * const audio = await gmi.audio.speech.create({
     *   model: MODELS.VOICE_SYNTH,
     *   input: creativeKit.voice_script,
     *   voice: "narrator",
     * });
     */

    /* ── Node 5: Composer — assemble final kit ──────────────── */
    const kit = {
      kit_id: kitId,
      team: teamName,
      created_at: new Date().toISOString(),
      status: "complete",
      team_profile: teamProfile,
      creative: creativeKit,
      assets: {
        matchday_poster: { prompt: creativeKit?.image_prompts?.matchday_poster, url: null },
        fan_hype_card:   { prompt: creativeKit?.image_prompts?.fan_hype_card, url: null },
        social_cover:    { prompt: creativeKit?.image_prompts?.social_cover, url: null },
        voice_hype:      { script: creativeKit?.voice_script, url: null },
        social_copy:     creativeKit?.social_copy || {},
        watch_party:     creativeKit?.watch_party || {},
        group_breakdown: {
          group: teamProfile?.group,
          opponents: teamProfile?.group_opponents,
          ai_prediction: `${teamName} advances from the group stage`,
        },
      },
    };

    kitStore.set(kitId, kit);

    return NextResponse.json({ kit_id: kitId, status: "complete", kit });
  } catch (error) {
    console.error("Pipeline error:", error);
    return NextResponse.json(
      { error: "Pipeline failed. Check API keys and model availability." },
      { status: 500 }
    );
  }
}
