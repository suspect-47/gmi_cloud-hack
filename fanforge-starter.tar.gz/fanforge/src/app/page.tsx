import Link from "next/link";
import { ROUTES } from "@/lib/constants";

export default function Home() {
  return (
    <div className="max-w-5xl mx-auto px-8 py-12">
      {/* Hero */}
      <section className="mb-16">
        <p className="text-caption text-text-tertiary mb-4">
          FIFA World Cup 2026 — 19 days to kickoff
        </p>
        <h1 className="text-display text-deep-orange mb-4">
          Your team.<br />
          Your voice.<br />
          Your content.
        </h1>
        <p className="text-lg text-text-secondary max-w-lg mb-8">
          Generate a complete fan content kit in seconds — matchday posters,
          social media copy, hype reels, and watch party kits. All from
          your&nbsp;voice.
        </p>

        <div className="flex items-center gap-4">
          <Link href={ROUTES.GENERATE}>
            <button className="btn-primary text-base px-8 py-3">
              Generate your kit
            </button>
          </Link>
          <span className="text-text-tertiary text-sm">
            or press <kbd className="px-2 py-0.5 bg-cream rounded text-xs font-body">Space</kbd> to start recording
          </span>
        </div>
      </section>

      {/* How it works */}
      <section className="mb-16">
        <h2 className="text-h2 text-text-primary mb-8">How it works</h2>
        <div className="grid grid-cols-3 gap-6 card-stagger">
          {[
            { step: "01", title: "Speak your team", desc: "Say who you support, name your favorite player, bring the energy." },
            { step: "02", title: "AI generates", desc: "6 pipeline nodes process your voice across 4 AI models in parallel." },
            { step: "03", title: "Share everywhere", desc: "Download posters, copy captions, share to Instagram, X, and TikTok." },
          ].map((item) => (
            <div key={item.step} className="card">
              <span className="text-caption text-orange">{item.step}</span>
              <h3 className="text-h3 text-deep-orange mt-2 mb-2">{item.title}</h3>
              <p className="text-sm text-text-secondary">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Sponsor footer */}
      <footer className="border-t border-t-[var(--color-border-light)] pt-6 flex items-center justify-center gap-8 text-text-tertiary text-sm">
        <span>Powered by</span>
        <span className="font-body font-bold text-text-secondary">RocketRide</span>
        <span>×</span>
        <span className="font-body font-bold text-text-secondary">GMI Cloud</span>
        <span>×</span>
        <span className="font-body font-bold text-text-secondary">Google AI Studio</span>
      </footer>
    </div>
  );
}
